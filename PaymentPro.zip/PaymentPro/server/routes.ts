import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { createPaymentSchema } from "@shared/schema";

if (!process.env.STRIPE_SECRET_KEY) {
  console.warn('Missing required Stripe secret: STRIPE_SECRET_KEY');
  console.warn('Please set your Stripe keys:');
  console.warn('1. Go to https://dashboard.stripe.com/apikeys');
  console.warn('2. VITE_STRIPE_PUBLIC_KEY - copy your "Publishable key" (starts with pk_)');
  console.warn('3. STRIPE_SECRET_KEY - copy your "Secret key" (starts with sk_)');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2025-03-31.basil",
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all transactions
  app.get("/api/transactions", async (req, res) => {
    try {
      const transactions = await storage.getTransactions();
      res.json(transactions);
    } catch (error: any) {
      res.status(500).json({ message: `Error fetching transactions: ${error.message}` });
    }
  });

  // Create a payment intent
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const validatedData = createPaymentSchema.parse(req.body);
      const { amount, description, cardholderName } = validatedData;
      
      // Create a PaymentIntent with the order amount and currency
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert dollars to cents
        currency: "usd",
        description,
        metadata: {
          description,
          cardholderName: cardholderName || "Not provided"
        },
      });

      res.json({ 
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id 
      });
    } catch (error: any) {
      console.error("Payment intent error:", error);
      
      // Format ZodErrors for a clearer response
      if (error.errors) {
        return res.status(400).json({ 
          message: `Error creating payment intent: ${JSON.stringify(error.errors, null, 1)}` 
        });
      }
      
      res.status(400).json({ message: `Error creating payment intent: ${error.message}` });
    }
  });

  // Create a transaction record after payment
  app.post("/api/transactions", async (req, res) => {
    try {
      const { 
        amount, 
        description, 
        paymentMethod, 
        lastFour, 
        stripePaymentId, 
        status, 
        email, 
        cardholderName 
      } = req.body;

      const transaction = await storage.createTransaction({
        amount, 
        description, 
        paymentMethod, 
        lastFour, 
        stripePaymentId, 
        status, 
        email, 
        cardholderName
      });

      res.status(201).json(transaction);
    } catch (error: any) {
      res.status(400).json({ message: `Error creating transaction: ${error.message}` });
    }
  });

  // Webhook for Stripe events (payment confirmations, etc.)
  app.post("/api/webhook", async (req, res) => {
    const payload = req.body;
    
    try {
      // Process different event types
      switch (payload.type) {
        case 'payment_intent.succeeded':
          // Handle successful payment
          // This would update the transaction status in a real implementation
          break;
          
        case 'payment_intent.payment_failed':
          // Handle failed payment
          break;
          
        default:
          // Unexpected event type
          console.log(`Unhandled event type ${payload.type}`);
      }

      res.json({ received: true });
    } catch (error: any) {
      res.status(400).json({ message: `Webhook Error: ${error.message}` });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
