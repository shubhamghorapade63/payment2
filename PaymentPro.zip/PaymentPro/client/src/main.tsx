import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Check for required Stripe key
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  console.warn('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
  console.warn('Please set your Stripe keys:');
  console.warn('1. Go to https://dashboard.stripe.com/apikeys');
  console.warn('2. VITE_STRIPE_PUBLIC_KEY - copy your "Publishable key" (starts with pk_)');
}

createRoot(document.getElementById("root")!).render(<App />);
