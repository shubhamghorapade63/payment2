import { format } from "date-fns";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";

interface PaymentSuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactionId: string;
  amount: number;
  date: string;
}

export default function PaymentSuccessModal({
  isOpen,
  onClose,
  transactionId,
  amount,
  date,
}: PaymentSuccessModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <div className="flex justify-center mb-2">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
            <CheckCircle2 className="h-6 w-6 text-green-600" />
          </div>
        </div>
        
        <DialogHeader>
          <DialogTitle className="text-center">Payment Successful</DialogTitle>
          <DialogDescription className="text-center">
            Your payment of <span className="font-medium">${amount.toFixed(2)}</span> has been processed successfully.
          </DialogDescription>
        </DialogHeader>
        
        <div className="mt-4 p-4 bg-gray-50 rounded-md">
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-500">Transaction ID:</span>
            <span className="font-medium">{transactionId}</span>
          </div>
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-500">Date:</span>
            <span className="font-medium">{date}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-500">Payment Method:</span>
            <span className="font-medium">•••• 4242</span>
          </div>
        </div>
        
        <DialogFooter className="mt-4">
          <Button onClick={onClose} className="w-full">
            Done
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
