import { Transaction } from "@shared/schema";
import { format, parseISO } from "date-fns";
import { Button } from "@/components/ui/button";
import { CreditCard, FileText } from "lucide-react";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";

interface TransactionListProps {
  transactions: Transaction[];
}

export default function TransactionList({ transactions }: TransactionListProps) {
  // Function to get status badge class
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'successful':
        return 'bg-green-100 text-green-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Function to format date
  const formatDate = (dateString: Date) => {
    if (!dateString) return 'N/A';
    if (typeof dateString === 'string') {
      return format(parseISO(dateString), 'MMM dd, yyyy');
    }
    return format(dateString, 'MMM dd, yyyy');
  };

  // Function to format amount from cents to dollars
  const formatAmount = (cents: number) => {
    return `$${(cents / 100).toFixed(2)}`;
  };

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Payment Method</th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {transactions.map((transaction) => (
            <tr key={transaction.id}>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {formatDate(transaction.date)}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                {transaction.description}
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                {formatAmount(transaction.amount)}
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(transaction.status)}`}>
                  {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                <div className="flex items-center space-x-2">
                  <CreditCard className="h-4 w-6" />
                  <span>•••• {transaction.lastFour}</span>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                <Dialog>
                  <DialogTrigger asChild>
                    <button className="text-primary hover:text-primary/80">
                      {transaction.status === 'successful' ? 'View Receipt' : 'View Details'}
                    </button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>
                        {transaction.status === 'successful' ? 'Payment Receipt' : 'Payment Details'}
                      </DialogTitle>
                      <DialogDescription>
                        Transaction ID: {transaction.stripePaymentId}
                      </DialogDescription>
                    </DialogHeader>
                    
                    <div className="space-y-4 my-4">
                      <div className="bg-gray-50 p-4 rounded-md">
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-500">Date:</span>
                          <span className="font-medium">{formatDate(transaction.date)}</span>
                        </div>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-500">Description:</span>
                          <span className="font-medium">{transaction.description}</span>
                        </div>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-500">Amount:</span>
                          <span className="font-medium">{formatAmount(transaction.amount)}</span>
                        </div>
                        <div className="flex justify-between text-sm mb-2">
                          <span className="text-gray-500">Status:</span>
                          <span className={`font-medium ${
                            transaction.status === 'successful' ? 'text-green-600' : 
                            transaction.status === 'failed' ? 'text-red-600' : 'text-yellow-600'
                          }`}>
                            {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">Payment Method:</span>
                          <span className="font-medium">•••• {transaction.lastFour}</span>
                        </div>
                        {transaction.cardholderName && (
                          <div className="flex justify-between text-sm mt-2">
                            <span className="text-gray-500">Cardholder:</span>
                            <span className="font-medium">{transaction.cardholderName}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <DialogFooter>
                      {transaction.status === 'successful' && (
                        <Button>
                          <FileText className="mr-2 h-4 w-4" />
                          Download Receipt
                        </Button>
                      )}
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
