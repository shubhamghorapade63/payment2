import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";

interface PaymentErrorModalProps {
  isOpen: boolean;
  onClose: () => void;
  errorMessage: string;
  onTryAgain: () => void;
}

export default function PaymentErrorModal({
  isOpen,
  onClose,
  errorMessage,
  onTryAgain,
}: PaymentErrorModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <div className="flex justify-center mb-2">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-red-100">
            <AlertTriangle className="h-6 w-6 text-red-600" />
          </div>
        </div>
        
        <DialogHeader>
          <DialogTitle className="text-center">Payment Failed</DialogTitle>
          <DialogDescription className="text-center">
            Your payment could not be processed. Please check your card details and try again.
          </DialogDescription>
        </DialogHeader>
        
        <div className="mt-4 p-4 bg-red-50 border border-red-100 rounded-md text-left">
          <p className="text-sm text-red-600 font-medium">Error: {errorMessage}</p>
        </div>
        
        <DialogFooter className="mt-4 flex space-x-2">
          <Button variant="outline" onClick={onClose} className="flex-1">
            Cancel
          </Button>
          <Button onClick={onTryAgain} className="flex-1">
            Try Again
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
