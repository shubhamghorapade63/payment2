import { pgTable, text, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  amount: integer("amount").notNull(), // In cents
  description: text("description").notNull(),
  paymentMethod: text("payment_method").notNull(),
  lastFour: text("last_four").notNull(), // Last 4 digits of card
  stripePaymentId: text("stripe_payment_id").notNull(),
  status: text("status").notNull(), // "successful", "failed", "pending"
  date: timestamp("date").notNull().defaultNow(),
  email: text("email"),
  cardholderName: text("cardholder_name"),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  date: true,
});

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

export const createPaymentSchema = z.object({
  amount: z.number().min(1), // Amount in dollars
  description: z.string().min(1),
  cardholderName: z.string().min(1).optional(),
  email: z.string().email().optional(),
});

export type CreatePayment = z.infer<typeof createPaymentSchema>;
