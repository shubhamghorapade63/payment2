import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { createPaymentSchema } from "@shared/schema";

// Validate Stripe keys
function isValidStripeKey(key: string | undefined): boolean {
  if (!key) return false;
  if (key === '1234') return false;
  if (key.includes('placeholder')) return false;
  // A valid Stripe key should start with sk_live_ or sk_test_
  if (!key.startsWith('sk_live_') && !key.startsWith('sk_test_')) return false;
  // And should be at least 10 characters
  if (key.length < 10) return false;
  return true;
}

const hasValidKey = isValidStripeKey(process.env.STRIPE_SECRET_KEY);

if (!hasValidKey) {
  console.warn('Invalid or missing Stripe secret key. Using mock mode for development.');
  console.warn('To use real Stripe integration, please set your Stripe keys:');
  console.warn('1. Go to https://dashboard.stripe.com/apikeys');
  console.warn('2. VITE_STRIPE_PUBLIC_KEY - copy your "Publishable key" (starts with pk_)');
  console.warn('3. STRIPE_SECRET_KEY - copy your "Secret key" (starts with sk_)');
}

// Mock Stripe implementation for development
const MOCK_MODE = !hasValidKey;
let stripe: Stripe;

if (MOCK_MODE) {
  // Create a mock Stripe implementation
  console.log('Using mock Stripe implementation for development');
  
  // Create a custom type to avoid TypeScript errors with our mock implementation
  class MockStripe {
    paymentIntents = {
      create: async ({ amount, currency, description, metadata }: any) => {
        console.log('MOCK: Creating payment intent', { amount, currency, description });
        // Generate mock payment intent with client_secret
        const id = `pi_mock_${Date.now()}`;
        return {
          id,
          object: 'payment_intent',
          client_secret: `pi_mock_secret_${id}`,
          amount,
          currency,
          description,
          metadata,
          status: 'requires_payment_method',
          // Add other required fields to match Stripe's PaymentIntent type
          created: Date.now() / 1000,
          livemode: false,
          payment_method_types: ['card'],
          // Add required fields but with null values
          amount_capturable: 0,
          amount_received: 0,
          application: null,
          application_fee_amount: null,
          automatic_payment_methods: null,
          canceled_at: null,
          cancellation_reason: null,
          capture_method: 'automatic',
          confirmation_method: 'automatic',
          last_payment_error: null,
          latest_charge: null,
          next_action: null,
          on_behalf_of: null,
          payment_method: null,
          payment_method_options: {},
          processing: null,
          receipt_email: null,
          review: null,
          setup_future_usage: null,
          shipping: null,
          statement_descriptor: null,
          statement_descriptor_suffix: null,
          transfer_data: null,
          transfer_group: null
        };
      }
    }
  }
  
  stripe = new MockStripe() as unknown as Stripe;
} else {
  // Initialize real Stripe client
  stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
    apiVersion: "2025-03-31.basil",
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all transactions
  app.get("/api/transactions", async (req, res) => {
    try {
      const transactions = await storage.getTransactions();
      res.json(transactions);
    } catch (error: any) {
      res.status(500).json({ message: `Error fetching transactions: ${error.message}` });
    }
  });

  // Create a payment intent
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const validatedData = createPaymentSchema.parse(req.body);
      const { amount, description, cardholderName } = validatedData;
      
      // Create a PaymentIntent with the order amount and currency
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert dollars to cents
        currency: "usd",
        description,
        metadata: {
          description,
          cardholderName: cardholderName || "Not provided"
        },
      });

      res.json({ 
        clientSecret: paymentIntent.client_secret,
        paymentIntentId: paymentIntent.id 
      });
    } catch (error: any) {
      console.error("Payment intent error:", error);
      
      // Format ZodErrors for a clearer response
      if (error.errors) {
        return res.status(400).json({ 
          message: `Error creating payment intent: ${JSON.stringify(error.errors, null, 1)}` 
        });
      }
      
      res.status(400).json({ message: `Error creating payment intent: ${error.message}` });
    }
  });

  // Create a transaction record after payment
  app.post("/api/transactions", async (req, res) => {
    try {
      const { 
        amount, 
        description, 
        paymentMethod, 
        lastFour, 
        stripePaymentId, 
        status, 
        email, 
        cardholderName 
      } = req.body;

      const transaction = await storage.createTransaction({
        amount, 
        description, 
        paymentMethod, 
        lastFour, 
        stripePaymentId, 
        status, 
        email, 
        cardholderName
      });

      res.status(201).json(transaction);
    } catch (error: any) {
      res.status(400).json({ message: `Error creating transaction: ${error.message}` });
    }
  });

  // Webhook for Stripe events (payment confirmations, etc.)
  app.post("/api/webhook", async (req, res) => {
    const payload = req.body;
    
    try {
      // Process different event types
      switch (payload.type) {
        case 'payment_intent.succeeded':
          // Handle successful payment
          const successfulPaymentIntent = payload.data.object;
          // Find transaction by stripe payment ID
          const transaction = await storage.getTransactionByStripeId(successfulPaymentIntent.id);
          if (transaction) {
            await storage.updateTransactionStatus(transaction.id, "successful");
            console.log(`Updated transaction ${transaction.id} status to successful`);
          }
          break;
          
        case 'payment_intent.payment_failed':
          // Handle failed payment
          const failedPaymentIntent = payload.data.object;
          const failedTransaction = await storage.getTransactionByStripeId(failedPaymentIntent.id);
          if (failedTransaction) {
            await storage.updateTransactionStatus(failedTransaction.id, "failed");
            console.log(`Updated transaction ${failedTransaction.id} status to failed`);
          }
          break;
          
        default:
          // Unexpected event type
          console.log(`Unhandled event type ${payload.type}`);
      }

      res.json({ received: true });
    } catch (error: any) {
      console.error("Webhook error:", error);
      res.status(400).json({ message: `Webhook Error: ${error.message}` });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
