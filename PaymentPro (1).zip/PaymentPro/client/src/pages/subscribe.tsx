import { useEffect, useState } from "react";
import { loadStripe } from "@stripe/stripe-js";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, CreditCard, Shield, Calendar, Check } from "lucide-react";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || 'pk_test_placeholder');

const SubscribeForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [cardholderName, setCardholderName] = useState("");
  const [email, setEmail] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    if (cardholderName.trim() === "") {
      toast({
        title: "Error",
        description: "Please enter the cardholder name",
        variant: "destructive",
      });
      return;
    }

    if (email.trim() === "") {
      toast({
        title: "Error",
        description: "Email is required for subscription notifications",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      // Confirm the payment
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          payment_method_data: {
            billing_details: {
              name: cardholderName,
              email: email,
            },
          },
          return_url: `${window.location.origin}/subscribe`,
        },
        redirect: "if_required",
      });

      if (error) {
        toast({
          title: "Subscription Failed",
          description: error.message,
          variant: "destructive",
        });
      } else if (paymentIntent && paymentIntent.status === "succeeded") {
        // Use default lastFour for simplicity
        let lastFour = "4242"; // Default for test mode
        console.log("Payment successful with ID:", paymentIntent.id);

        // Record the transaction as a subscription
        await apiRequest("POST", "/api/transactions", {
          amount: 19.99 * 100, // Convert to cents
          description: "Premium Monthly Subscription",
          paymentMethod: "card",
          lastFour,
          stripePaymentId: paymentIntent.id,
          status: "successful",
          email,
          cardholderName,
        });

        toast({
          title: "Subscription Activated",
          description: "Thank you for subscribing to our service!",
        });
      }
    } catch (err: any) {
      toast({
        title: "Subscription Error",
        description: err.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* Card Holder Name */}
      <div className="mb-4">
        <Label htmlFor="cardholder-name" className="block text-sm font-medium text-gray-700 mb-1">Cardholder Name</Label>
        <Input 
          type="text" 
          id="cardholder-name" 
          placeholder="John Smith" 
          value={cardholderName}
          onChange={(e) => setCardholderName(e.target.value)}
          required
        />
      </div>

      {/* Email (Required for subscriptions) */}
      <div className="mb-4">
        <Label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email</Label>
        <Input 
          type="email" 
          id="email" 
          placeholder="you@example.com" 
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <p className="text-xs text-gray-500 mt-1">We'll send receipts and subscription updates to this email.</p>
      </div>
      
      {/* Card Details Fields */}
      <div className="mb-4">
        <Label htmlFor="card-element" className="block text-sm font-medium text-gray-700 mb-1">Card Information</Label>
        <div className="mt-1">
          <PaymentElement id="card-element" />
        </div>
      </div>
      
      {/* Payment Button */}
      <div>
        <Button 
          type="submit" 
          className="w-full py-3" 
          disabled={!stripe || isLoading}
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            'Subscribe Now'
          )}
        </Button>
      </div>
      
      {/* Security Notice */}
      <div className="mt-4 flex items-center justify-center text-xs text-gray-500">
        <Shield className="h-4 w-4 mr-1" />
        Secured by Stripe. You can cancel your subscription anytime.
      </div>
    </form>
  );
};

export default function Subscribe() {
  const [clientSecret, setClientSecret] = useState("");
  const [selectedPlan, setSelectedPlan] = useState("monthly");

  // Pricing plans
  const plans = {
    monthly: {
      price: 19.99,
      period: "month",
      savings: 0
    },
    yearly: {
      price: 199.99,
      period: "year",
      savings: 39.89
    }
  };

  // Create PaymentIntent as soon as component loads
  useEffect(() => {
    apiRequest("POST", "/api/create-payment-intent", { 
      amount: plans[selectedPlan as keyof typeof plans].price, 
      description: `Premium ${selectedPlan.charAt(0).toUpperCase() + selectedPlan.slice(1)} Subscription` 
    })
      .then((res) => res.json())
      .then((data) => {
        setClientSecret(data.clientSecret);
      })
      .catch(err => {
        console.error("Failed to initialize payment: " + err.message);
      });
  }, [selectedPlan]);

  return (
    <div className="tab-content">
      <div className="grid md:grid-cols-2 gap-8">
        {/* Plan Selection Section */}
        <div className="bg-white rounded-lg shadow-sm p-6 order-1">
          <h2 className="text-xl font-semibold mb-6">Choose Your Subscription</h2>
          
          <div className="space-y-4">
            {/* Plan Selection */}
            <div className="mb-6">
              <Label htmlFor="plan-select" className="block text-sm font-medium text-gray-700 mb-1">Billing Period</Label>
              <Select 
                value={selectedPlan} 
                onValueChange={setSelectedPlan}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select plan" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="yearly">Yearly (Save 16%)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {/* Plan Cards */}
            <div className="space-y-3">
              <Card className={`border-2 ${selectedPlan === 'monthly' ? 'border-primary' : 'border-gray-200'}`}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex justify-between items-center">
                    <span>Monthly</span>
                    {selectedPlan === 'monthly' && <Check className="h-5 w-5 text-primary" />}
                  </CardTitle>
                  <CardDescription>Flexible month-to-month billing</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-1">${plans.monthly.price}<span className="text-sm font-normal text-gray-500">/month</span></div>
                  <div className="text-sm text-gray-500">Billed monthly</div>
                </CardContent>
              </Card>
              
              <Card className={`border-2 ${selectedPlan === 'yearly' ? 'border-primary' : 'border-gray-200'}`}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-lg flex items-center">
                      <span>Yearly</span>
                      {selectedPlan === 'yearly' && <Check className="h-5 w-5 text-primary ml-2" />}
                    </CardTitle>
                    <div className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-medium">Save ${plans.yearly.savings}</div>
                  </div>
                  <CardDescription>Best value for long-term users</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-1">${plans.yearly.price}<span className="text-sm font-normal text-gray-500">/year</span></div>
                  <div className="text-sm text-gray-500">Billed annually</div>
                </CardContent>
              </Card>
            </div>
            
            {/* Feature List */}
            <div className="py-4">
              <h3 className="text-sm font-medium mb-3">All plans include:</h3>
              <ul className="space-y-2">
                <li className="flex items-center text-sm">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  Full access to all premium features
                </li>
                <li className="flex items-center text-sm">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  Priority customer support
                </li>
                <li className="flex items-center text-sm">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  Cancel anytime with no penalties
                </li>
                <li className="flex items-center text-sm">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  Automatic renewal for uninterrupted service
                </li>
              </ul>
            </div>
          </div>
        </div>
        
        {/* Payment Form Section */}
        <div className="bg-white rounded-lg shadow-sm p-6 order-2">
          <h2 className="text-xl font-semibold mb-4">Payment Details</h2>
          <p className="text-gray-600 mb-6">You're subscribing to our {selectedPlan} plan.</p>
          
          {/* Alert for test mode */}
          <div className="mb-6 bg-blue-50 border border-blue-200 rounded-md p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-blue-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-blue-700">
                  This is a demo subscription form. Use test card number: <strong>4242 4242 4242 4242</strong> with any future expiration date and CVC.
                </p>
              </div>
            </div>
          </div>
          
          {!clientSecret ? (
            <div className="flex items-center justify-center py-10">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" aria-label="Loading"/>
            </div>
          ) : (
            <Elements stripe={stripePromise} options={{ clientSecret, appearance: { theme: 'stripe' } }}>
              <SubscribeForm />
            </Elements>
          )}
        </div>
      </div>
    </div>
  );
}