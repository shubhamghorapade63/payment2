import { useEffect, useState } from "react";
import { loadStripe } from "@stripe/stripe-js";
import PaymentForm from "@/components/payment-form";
import PaymentSuccessModal from "@/components/payment-success-modal";
import PaymentErrorModal from "@/components/payment-error-modal";
import { Card, CardContent } from "@/components/ui/card";
import { Package } from "lucide-react";

// Make sure to call `loadStripe` outside of a component's render to avoid
// recreating the `Stripe` object on every render.
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || 'pk_test_placeholder');

export default function Payment() {
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [paymentData, setPaymentData] = useState({
    amount: 99.99,
    description: "Premium Product Package",
    cardholderName: "",
  });
  const [errorMessage, setErrorMessage] = useState("");
  const [transactionId, setTransactionId] = useState("");
  const [paymentDate, setPaymentDate] = useState("");

  // Handler for successful payment
  const handlePaymentSuccess = (data: { 
    transactionId: string, 
    amount: number, 
    date: string,
    lastFour: string 
  }) => {
    setTransactionId(data.transactionId);
    setPaymentDate(data.date);
    setShowSuccessModal(true);
  };

  // Handler for failed payment
  const handlePaymentError = (error: string) => {
    setErrorMessage(error);
    setShowErrorModal(true);
  };

  return (
    <div className="tab-content">
      <div className="grid md:grid-cols-2 gap-8">
        {/* Payment Form Section */}
        <div className="bg-white rounded-lg shadow-sm p-6 order-2 md:order-1">
          <h2 className="text-xl font-semibold mb-6">Payment Details</h2>
          
          {/* Alert for test mode */}
          <div className="mb-6 bg-blue-50 border border-blue-200 rounded-md p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-blue-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2h-1V9z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-blue-700">
                  This is a demo payment form. Use test card number: <strong>4242 4242 4242 4242</strong>
                </p>
              </div>
            </div>
          </div>
          
          <PaymentForm 
            amount={paymentData.amount}
            description={paymentData.description}
            onSuccess={handlePaymentSuccess}
            onError={handlePaymentError}
            stripePromise={stripePromise}
          />
        </div>
        
        {/* Order Summary Section */}
        <div className="bg-white rounded-lg shadow-sm p-6 h-fit order-1 md:order-2">
          <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
          
          {/* Product Details */}
          <div className="border-b border-gray-200 pb-4 mb-4">
            <div className="flex items-center space-x-4 mb-4">
              <div className="bg-gray-100 rounded-md h-16 w-16 flex items-center justify-center">
                <Package className="h-8 w-8 text-gray-400" />
              </div>
              <div className="flex-1">
                <h3 className="text-sm font-medium">Premium Product Package</h3>
                <p className="text-xs text-gray-500">Annual subscription</p>
              </div>
              <div className="text-sm font-medium">${paymentData.amount.toFixed(2)}</div>
            </div>
          </div>
          
          {/* Cost Breakdown */}
          <div className="space-y-2 mb-4">
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Subtotal</span>
              <span className="text-sm font-medium">${paymentData.amount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Tax</span>
              <span className="text-sm font-medium">$0.00</span>
            </div>
          </div>
          
          {/* Total Cost */}
          <div className="flex justify-between border-t border-gray-200 pt-4">
            <span className="text-base font-medium">Total</span>
            <span className="text-base font-medium">${paymentData.amount.toFixed(2)}</span>
          </div>
          
          {/* Virtual Card Display */}
          <div className="mt-6">
            <div className="bg-gradient-to-br from-primary to-secondary rounded-lg p-4 text-white shadow-lg">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <p className="text-xs font-light opacity-80">Secure Payment</p>
                  <p className="font-medium">SecurePay Gateway</p>
                </div>
                <svg className="h-8 w-8" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M22 10V9C22 6.79086 20.2091 5 18 5H6C3.79086 5 2 6.79086 2 9V15C2 17.2091 3.79086 19 6 19H18C20.2091 19 22 17.2091 22 15V14" stroke="white" strokeWidth="2" strokeLinecap="round"/>
                  <path d="M6 9H8" stroke="white" strokeWidth="2" strokeLinecap="round"/>
                  <path d="M6 12H10" stroke="white" strokeWidth="2" strokeLinecap="round"/>
                  <path d="M6 15H8" stroke="white" strokeWidth="2" strokeLinecap="round"/>
                </svg>
              </div>
              <div className="flex justify-between items-center">
                <p className="text-lg tracking-wider">•••• •••• •••• 4242</p>
                <div className="flex space-x-2">
                  <span className="text-xs">Powered by</span>
                  <svg className="h-5" viewBox="0 0 60 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M59.6 14.4C59.6 9.7 55.8 6 51.1 6C46.4 6 42.6 9.7 42.6 14.4C42.6 19.1 46.4 22.8 51.1 22.8C55.8 22.8 59.6 19.1 59.6 14.4ZM55.9 14.4C55.9 17.1 53.7 19.3 51.1 19.3C48.5 19.3 46.3 17.1 46.3 14.4C46.3 11.7 48.5 9.5 51.1 9.5C53.7 9.5 55.9 11.7 55.9 14.4ZM41.7 7.7V6.5H35.6V22.3H41.7V13.7C41.7 11.5 43.5 10 45.2 10C45.7 10 46.1 10.1 46.6 10.2V6.5C45.2 6.2 43.7 6.6 42.6 7.6C42.2 7.7 41.9 7.7 41.7 7.7ZM30.9 6.5H24.8V22.3H30.9V6.5ZM30.9 5C30.9 3.2 29.4 1.7 27.6 1.7C25.8 1.7 24.3 3.2 24.3 5C24.3 6.8 25.8 8.3 27.6 8.3C29.4 8.3 30.9 6.8 30.9 5ZM20 14.9V22.3H13.9V15.6C13.9 13.4 13 12.3 11.1 12.3C9.2 12.3 7.8 13.7 7.8 16.5V22.3H1.7V6.5H7.8V8.9C9 7.1 10.8 6 13.3 6C16.9 6 20 8.5 20 14.9Z" fill="white"/>
                  </svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Success Modal */}
      <PaymentSuccessModal
        isOpen={showSuccessModal}
        onClose={() => setShowSuccessModal(false)}
        transactionId={transactionId}
        amount={paymentData.amount}
        date={paymentDate}
      />

      {/* Payment Error Modal */}
      <PaymentErrorModal
        isOpen={showErrorModal}
        onClose={() => setShowErrorModal(false)}
        errorMessage={errorMessage}
        onTryAgain={() => setShowErrorModal(false)}
      />
    </div>
  );
}
