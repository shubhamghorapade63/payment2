import { useEffect } from "react";
import { useLocation } from "wouter";

export default function Home() {
  const [_, setLocation] = useLocation();
  
  // Redirect to payment page
  useEffect(() => {
    setLocation("/payment");
  }, [setLocation]);
  
  return null;
}
