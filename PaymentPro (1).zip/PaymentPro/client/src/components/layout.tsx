import { ReactNode } from "react";
import { useLocation, Link } from "wouter";
import { Calculator, CreditCard, History } from "lucide-react";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center space-x-2 cursor-pointer">
              <CreditCard className="h-8 w-8 text-primary" />
              <h1 className="text-xl font-semibold text-secondary">SecurePay</h1>
            </div>
          </Link>
          <div className="flex items-center space-x-4">
            <Link href="/">
              <button className="text-sm text-gray-600 hover:text-primary transition">Help</button>
            </Link>
            <div className="flex items-center space-x-1">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              <span className="text-sm font-medium">Connected to Stripe</span>
            </div>
          </div>
        </div>
      </header>
      
      {/* Main Content */}
      <main className="flex-grow py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Tabs Navigation */}
          <div className="border-b border-gray-200 mb-6">
            <nav className="-mb-px flex space-x-8">
              <Link href="/payment">
                <a className={`px-1 pb-3 border-b-2 font-medium text-sm ${
                  location === "/payment" || location === "/" 
                    ? "text-primary border-primary" 
                    : "text-gray-500 hover:text-gray-700 border-transparent"
                }`}>
                  Make Payment
                </a>
              </Link>
              <Link href="/history">
                <a className={`px-1 pb-3 border-b-2 font-medium text-sm ${
                  location === "/history" 
                    ? "text-primary border-primary" 
                    : "text-gray-500 hover:text-gray-700 border-transparent"
                }`}>
                  Transaction History
                </a>
              </Link>
            </nav>
          </div>
          
          {/* Page Content */}
          {children}
        </div>
      </main>
      
      {/* Footer */}
      <footer className="bg-white border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-4 mb-4 md:mb-0">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
              </svg>
              <span className="text-sm text-gray-500">All payments are secure and encrypted.</span>
            </div>
            <div className="flex items-center space-x-6">
              <div className="flex items-center">
                <span className="text-sm mr-3 text-gray-500">Powered by</span>
                <svg className="h-6" viewBox="0 0 60 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M59.6 14.4C59.6 9.7 55.8 6 51.1 6C46.4 6 42.6 9.7 42.6 14.4C42.6 19.1 46.4 22.8 51.1 22.8C55.8 22.8 59.6 19.1 59.6 14.4ZM55.9 14.4C55.9 17.1 53.7 19.3 51.1 19.3C48.5 19.3 46.3 17.1 46.3 14.4C46.3 11.7 48.5 9.5 51.1 9.5C53.7 9.5 55.9 11.7 55.9 14.4ZM41.7 7.7V6.5H35.6V22.3H41.7V13.7C41.7 11.5 43.5 10 45.2 10C45.7 10 46.1 10.1 46.6 10.2V6.5C45.2 6.2 43.7 6.6 42.6 7.6C42.2 7.7 41.9 7.7 41.7 7.7ZM30.9 6.5H24.8V22.3H30.9V6.5ZM30.9 5C30.9 3.2 29.4 1.7 27.6 1.7C25.8 1.7 24.3 3.2 24.3 5C24.3 6.8 25.8 8.3 27.6 8.3C29.4 8.3 30.9 6.8 30.9 5ZM20 14.9V22.3H13.9V15.6C13.9 13.4 13 12.3 11.1 12.3C9.2 12.3 7.8 13.7 7.8 16.5V22.3H1.7V6.5H7.8V8.9C9 7.1 10.8 6 13.3 6C16.9 6 20 8.5 20 14.9Z" fill="#635BFF"/>
                </svg>
              </div>
              <div className="h-6 border-l border-gray-300"></div>
              <div className="flex items-center space-x-2">
                <svg className="h-5 w-8" viewBox="0 0 40 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect width="40" height="24" rx="4" fill="#E8E8E8"/>
                  <path d="M14.5 8H25.5V16H14.5V8Z" fill="#FF5F00"/>
                  <path d="M15.5 12C15.5 10.3 16.4 8.8 17.8 8C16.7 7.2 15.4 6.8 14 6.8C10.6 6.8 8 9.1 8 12C8 14.9 10.6 17.2 14 17.2C15.4 17.2 16.7 16.8 17.8 16C16.4 15.2 15.5 13.7 15.5 12Z" fill="#EB001B"/>
                  <path d="M32 12C32 14.9 29.4 17.2 26 17.2C24.6 17.2 23.3 16.8 22.2 16C23.6 15.2 24.5 13.7 24.5 12C24.5 10.3 23.6 8.8 22.2 8C23.3 7.2 24.6 6.8 26 6.8C29.4 6.8 32 9.1 32 12Z" fill="#F79E1B"/>
                </svg>
                <svg className="h-5 w-8" viewBox="0 0 40 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect width="40" height="24" rx="4" fill="#E8E8E8"/>
                  <path d="M16.4 15.6H14.5L13 8.4H14.9L15.8 13.2L17.3 8.4H19.2L16.4 15.6Z" fill="#0066EB"/>
                  <path d="M19.5 15.6H21.3L22.7 8.4H20.9L19.5 15.6Z" fill="#0066EB"/>
                  <path d="M23.2 15.6H25L26.4 8.4H24.6L23.2 15.6Z" fill="#0066EB"/>
                  <path d="M30.9 8.4L29.2 13.2L28.7 8.4H26.9L28 15.6H29.9L32.7 8.4H30.9Z" fill="#0066EB"/>
                </svg>
                <svg className="h-5 w-8" viewBox="0 0 40 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect width="40" height="24" rx="4" fill="#E8E8E8"/>
                  <path d="M23.3 8H17.7C15.6 8 14 9.6 14 11.6V16.4C14 18.4 15.6 20 17.7 20H23.3C25.4 20 27 18.4 27 16.4V11.6C27 9.6 25.4 8 23.3 8Z" fill="#016FD0"/>
                  <path d="M17.7 15.1H23.3V16.9H17.7V15.1Z" fill="white"/>
                  <path d="M20.5 11.1C20.5 10.5 20.9 10 21.6 10C22.2 10 22.6 10.4 22.6 11.1C22.6 11.7 22.2 12.2 21.6 12.2C20.9 12.2 20.5 11.7 20.5 11.1Z" fill="white"/>
                  <path d="M18.4 11.1C18.4 10.5 18.8 10 19.5 10C20.1 10 20.5 10.4 20.5 11.1C20.5 11.7 20.1 12.2 19.5 12.2C18.8 12.2 18.4 11.7 18.4 11.1Z" fill="white"/>
                  <path d="M19.5 12.2C18.9 12.2 18.4 12.6 18.4 13.3V14.6H20.5V13.3C20.5 12.6 20.1 12.2 19.5 12.2Z" fill="white"/>
                  <path d="M21.5 12.2C20.9 12.2 20.4 12.6 20.4 13.3V14.6H22.5V13.3C22.6 12.6 22.1 12.2 21.5 12.2Z" fill="white"/>
                </svg>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
