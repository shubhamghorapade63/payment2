import { useState, useEffect } from "react";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Stripe, StripeElements } from "@stripe/stripe-js";

interface CheckoutFormProps {
  amount: number;
  description: string;
  onSuccess: (data: { 
    transactionId: string; 
    amount: number; 
    date: string;
    lastFour: string;
  }) => void;
  onError: (error: string) => void;
}

const CheckoutForm = ({ amount, description, onSuccess, onError }: CheckoutFormProps) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [cardholderName, setCardholderName] = useState("");
  const [email, setEmail] = useState("");
  const [saveCard, setSaveCard] = useState(false);
  
  // Function to check if we're in mock/development mode by looking at the client secret
  const isMockMode = (secret: string): boolean => secret.includes('mock');
  // Context from the Elements component will contain the client secret
  const elementsOptions = elements?.getElement(PaymentElement) as any;
  const currentClientSecret = elementsOptions?.options?.clientSecret as string | undefined;
  const mockModeActive = currentClientSecret ? isMockMode(currentClientSecret) : false;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    if (cardholderName.trim() === "") {
      toast({
        title: "Error",
        description: "Please enter the cardholder name",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      let paymentResult;
      let lastFour = "4242"; // Default for test/mock mode
      let paymentIntentId;
      
      if (mockModeActive) {
        // Mock implementation for development (when Stripe keys aren't valid)
        console.log('Using mock payment confirmation');
        // Simulate a successful payment
        paymentResult = {
          error: null,
          paymentIntent: {
            id: `pi_mock_${Date.now()}`,
            status: "succeeded",
            payment_method: `pm_mock_${Date.now()}`
          }
        };
        paymentIntentId = paymentResult.paymentIntent.id;
      } else {
        // Real Stripe implementation
        paymentResult = await stripe.confirmPayment({
          elements,
          confirmParams: {
            payment_method_data: {
              billing_details: {
                name: cardholderName,
                email: email || undefined,
              },
            },
            return_url: `${window.location.origin}/payment`,
          },
          redirect: "if_required",
        });
        
        if (paymentResult.paymentIntent) {
          paymentIntentId = paymentResult.paymentIntent.id;
        }
      }

      if (paymentResult.error) {
        onError(paymentResult.error.message || "Payment failed");
        toast({
          title: "Payment Failed",
          description: paymentResult.error.message || "Payment processing failed",
          variant: "destructive",
        });
      } else if (paymentResult.paymentIntent && 
                (paymentResult.paymentIntent.status === "succeeded" || mockModeActive)) {
        
        // Record the transaction in our database
        const transaction = await apiRequest("POST", "/api/transactions", {
          amount: amount * 100, // Convert to cents
          description,
          paymentMethod: "card",
          lastFour,
          stripePaymentId: paymentIntentId,
          status: "successful",
          email: email || undefined,
          cardholderName,
        });

        // Call the success handler
        onSuccess({
          transactionId: paymentIntentId || 'mock_transaction',
          amount,
          date: format(new Date(), "MMM dd, yyyy"),
          lastFour
        });

        toast({
          title: "Payment Successful",
          description: "Thank you for your purchase!",
        });
      }
    } catch (err: any) {
      onError(err.message || "An unexpected error occurred");
      toast({
        title: "Payment Error",
        description: err.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      {/* Amount Field - In a real app, this would be dynamic */}
      <div className="mb-4">
        <Label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-1">Amount</Label>
        <div className="relative rounded-md shadow-sm">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <span className="text-gray-500 sm:text-sm">$</span>
          </div>
          <Input 
            type="text" 
            name="amount" 
            id="amount" 
            className="pl-7 pr-12" 
            value={amount.toFixed(2)} 
            readOnly 
          />
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
            <span className="text-gray-500 sm:text-sm">USD</span>
          </div>
        </div>
      </div>
      
      {/* Description Field */}
      <div className="mb-4">
        <Label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">Description</Label>
        <Input 
          type="text" 
          name="description" 
          id="description" 
          value={description} 
          readOnly 
        />
      </div>
      
      {/* Card Holder Name */}
      <div className="mb-4">
        <Label htmlFor="cardholder-name" className="block text-sm font-medium text-gray-700 mb-1">Cardholder Name</Label>
        <Input 
          type="text" 
          id="cardholder-name" 
          placeholder="John Smith" 
          value={cardholderName}
          onChange={(e) => setCardholderName(e.target.value)}
          required
        />
      </div>

      {/* Email (Optional) */}
      <div className="mb-4">
        <Label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email (Optional)</Label>
        <Input 
          type="email" 
          id="email" 
          placeholder="you@example.com" 
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      
      {/* Card Details Fields */}
      <div className="mb-4">
        <Label htmlFor="card-element" className="block text-sm font-medium text-gray-700 mb-1">Card Information</Label>
        <div className="mt-1">
          <PaymentElement id="card-element" />
        </div>
      </div>
      
      {/* Save Card Checkbox */}
      <div className="flex items-center mb-6">
        <Checkbox 
          id="save-card" 
          checked={saveCard}
          onCheckedChange={(checked) => setSaveCard(checked as boolean)}
        />
        <Label htmlFor="save-card" className="ml-2 block text-sm text-gray-700">Save card for future payments</Label>
      </div>
      
      {/* Payment Button */}
      <div>
        <Button 
          type="submit" 
          className="w-full py-3" 
          disabled={!stripe || isLoading}
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            `Pay $${amount.toFixed(2)}`
          )}
        </Button>
      </div>
      
      {/* Security Notice */}
      <div className="mt-4 flex items-center justify-center text-xs text-gray-500">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
        </svg>
        Secured by Stripe. We don't store your card details.
      </div>
    </form>
  );
};

interface PaymentFormWrapperProps {
  amount: number;
  description: string;
  onSuccess: (data: { 
    transactionId: string; 
    amount: number; 
    date: string;
    lastFour: string;
  }) => void;
  onError: (error: string) => void;
  stripePromise: Promise<Stripe | null>;
}

export default function PaymentForm({ amount, description, onSuccess, onError, stripePromise }: PaymentFormWrapperProps) {
  const [clientSecret, setClientSecret] = useState("");

  // Create PaymentIntent as soon as component loads
  useEffect(() => {
    apiRequest("POST", "/api/create-payment-intent", { 
      amount, 
      description
    })
      .then((res) => res.json())
      .then((data) => {
        setClientSecret(data.clientSecret);
      })
      .catch(err => {
        onError("Failed to initialize payment: " + err.message);
      });
  }, [amount, description, onError]);

  if (!clientSecret) {
    return (
      <div className="flex items-center justify-center py-10">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" aria-label="Loading"/>
      </div>
    );
  }

  return (
    <Elements stripe={stripePromise} options={{ clientSecret, appearance: { theme: 'stripe' } }}>
      <CheckoutForm 
        amount={amount} 
        description={description} 
        onSuccess={onSuccess}
        onError={onError}
      />
    </Elements>
  );
}
